# -*- coding: utf-8 -*-
"""
Created on June 10

@author: Ali
"""
import numpy
# fix random seed for reproducibility
seed = 7
numpy.random.seed(seed)
# Create first network with Keras
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Activation
from keras.utils import np_utils
from keras import optimizers
from keras.layers.convolutional import Conv2D, ZeroPadding2D
from keras.layers.pooling import MaxPooling2D
from keras.layers.core import Dropout, Flatten
import math
from keras.callbacks import LearningRateScheduler
from keras.callbacks import Callback
from keras import optimizers
from keras.models import Sequential
from keras.layers import Dense
from keras.utils.vis_utils import plot_model
from keras import optimizers
from keras.models import Sequential
#keras.optimizers.SGD(learning_rate=0.01, momentum=0.0, nesterov=False)
#keras.optimizers.RMSprop(learning_rate=0.001, rho=0.9)
from keras import optimizers
from keras.optimizers import SGD
from keras.optimizers import Adam
from keras.optimizers import Adadelta
from keras.optimizers import Adagrad
from keras.optimizers import RMSprop
from keras.callbacks import ModelCheckpoint
import keras
from keras.models import Sequential,Input,Model
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.layers.normalization import BatchNormalization
from keras.layers.advanced_activations import LeakyReLU
import keras
import pydot as pyd
from IPython.display import SVG
from keras.utils.vis_utils import model_to_dot

keras.utils.vis_utils.pydot = pyd

#Visualize Model

def visualize_model(model):
  return SVG(model_to_dot(model).create(prog='dot', format='svg'))
#create your model
#then call the function on your model
print(__doc__)

import matplotlib.pyplot as plt


#define params
trn_file = 'data/DeepUPBPs_cv.csv'
tst_file = 'data/DeepUPBPs_Indi.csv'



num_features = 400
nb_classes = 2
nb_kernels = 3
nb_pools = 2
batch_size = 10
window_sizes = 20
epochs = 150

# load training dataset
============================

# Model
============================
model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3),activation='linear',padding='same',input_shape=(1, 20,20)))
model.add(LeakyReLU(alpha=0.1))
model.add(MaxPooling2D((2, 2),padding='same'))
model.add(Dropout(0.4))
model.add(Conv2D(64, (3, 3), activation='linear',padding='same'))
model.add(LeakyReLU(alpha=0.1))
model.add(MaxPooling2D(pool_size=(2, 2),padding='same'))
model.add(Dropout(0.4))
model.add(Conv2D(128, (3, 3), activation='linear',padding='same'))
model.add(LeakyReLU(alpha=0.1))                  
model.add(MaxPooling2D(pool_size=(2, 2),padding='same'))
model.add(Dropout(0.4))
model.add(Flatten())
model.add(Dense(128, activation='linear'))
model.add(LeakyReLU(alpha=0.1))           
model.add(Dropout(0.4))
model.add(Dense(nb_classes, activation='softmax'))
    

# Compile model
model.compile(loss=keras.losses.categorical_crossentropy, optimizer=keras.optimizers.Adam(),metrics=['accuracy'])
model.summary()     
      
pspd_train_dropout = model.fit(X, Y, validation_data=(X1, Y1), epochs=epochs, batch_size=batch_size,verbose=1)
#pspd_train = model.fit(X, Y, batch_size=batch_size,epochs=epochs,verbose=1,validation_data=(X1, Y1))
# evaluate the model
    
model.save("DDE_model_dropout.h5py")

#test_eval = model.evaluate(X, Y, verbose=1)
test_eval = model.evaluate(X, Y, verbose=0)
print('Test loss:', test_eval[0])
print('Test accuracy:', test_eval[1])

